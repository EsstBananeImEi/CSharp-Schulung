﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ToDoApp.Business
{
    public class ToDo
    {
        public int ID { get; set; }
        

        public string Title { get; set; }

        public DateTime? Date { get; set; }

        public List<ToDoApp.Business.ToDoCategory> Categories { get; set; }

        public string Body { get; set; }

        public ToDo() : this("Neue Aufgabe")
        {            
        }

        public ToDo(string myTitle)
        {            
            Title = myTitle;
            Date = DateTime.Now.Date;
            Categories = new List<ToDoCategory>();
            Body = "";
        }
    }
}